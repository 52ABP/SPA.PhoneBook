## Introduction

This is the VueJs client for [ASP.NET Boilerplate](https://aspnetboilerplate.com/Pages/Documents)'s ASP.NET Core MVC template. Thanks to [@xiaochong44](http://github.com/xiaochong44) for providing the initial template.

## Install dependencies

```bush
npm install
```
or

```bush
yarn
```

## Run

### Development
```bush
npm run dev
```
### Production(Build)
```bush
npm run build
```
