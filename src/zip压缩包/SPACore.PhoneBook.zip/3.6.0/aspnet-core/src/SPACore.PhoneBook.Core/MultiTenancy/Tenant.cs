﻿using Abp.MultiTenancy;
using SPACore.PhoneBook.Authorization.Users;

namespace SPACore.PhoneBook.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
